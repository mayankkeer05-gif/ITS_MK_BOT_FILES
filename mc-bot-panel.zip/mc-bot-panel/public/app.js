'use strict';

const $ = (id) => document.getElementById(id);
const STATE_LABEL = { stopped: 'Stopped', connecting: 'Connecting', online: 'Online', away: 'Away', reconnecting: 'Reconnecting' };
const MAX_CONSOLE_LINES = 500;

const S = { max: 10, bots: new Map(), selected: null, es: null };

/* ------------------------------------------------------------ helpers */
function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v);
  }
  for (const c of kids) if (c != null) n.append(c);
  return n;
}

let toastTimer = null;
function toast(msg, isError = false) {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast show' + (isError ? ' error' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = 'toast'), 3200);
}

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* no body */
  }
  if (res.status === 401 && path !== '/login') {
    showLogin();
    throw new Error('Login required');
  }
  if (!res.ok) throw new Error((data && data.error) || `Error ${res.status}`);
  return data;
}

function fmtDur(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h) return `${h}h ${String(m).padStart(2, '0')}m ${String(sec).padStart(2, '0')}s`;
  return `${m}m ${String(sec).padStart(2, '0')}s`;
}
const fmtTime = (t) => new Date(t).toLocaleTimeString([], { hour12: false });

/* ------------------------------------------------------------ login */
function showLogin() {
  if (S.es) {
    S.es.close();
    S.es = null;
  }
  $('app').classList.add('hidden');
  $('login').classList.remove('hidden');
  $('loginPw').focus();
}

$('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('loginErr').textContent = '';
  try {
    await api('/login', { method: 'POST', body: { password: $('loginPw').value } });
    $('loginPw').value = '';
    boot();
  } catch (err) {
    $('loginErr').textContent = err.message;
  }
});

$('logoutBtn').addEventListener('click', async () => {
  try {
    await api('/logout', { method: 'POST' });
  } catch {
    /* ignore */
  }
  S.selected = null;
  showLogin();
});

/* ------------------------------------------------------------ bot list */
async function loadList() {
  const data = await api('/bots');
  S.max = data.max;
  S.bots = new Map(data.bots.map((b) => [b.id, b]));
  if (S.selected && !S.bots.has(S.selected)) {
    S.selected = null;
    history.replaceState(null, '', location.pathname);
  }
  renderList();
  renderDetail();
}

function renderList() {
  const box = $('botList');
  box.replaceChildren();
  for (const b of S.bots.values()) {
    box.append(
      el(
        'button',
        { class: 'bot-item' + (b.id === S.selected ? ' active' : ''), type: 'button', role: 'listitem', onclick: () => select(b.id) },
        el('span', { class: 's-' + b.state + ' pip' }),
        el('span', { class: 'bot-meta' }, el('b', { text: b.name }), el('small', { text: `${b.host}:${b.port}` })),
        el('span', { class: 'bot-state', text: STATE_LABEL[b.state] || b.state })
      )
    );
  }
  $('count').textContent = `${S.bots.size}/${S.max}`;
  $('newBtn').disabled = S.bots.size >= S.max;
}

/* ------------------------------------------------------------ detail */
async function select(id) {
  S.selected = id;
  history.replaceState(null, '', '#' + id);
  renderList();
  renderDetail();
  $('console').replaceChildren();
  try {
    const [d, l] = await Promise.all([api('/bots/' + id), api(`/bots/${id}/logs`)]);
    if (S.selected !== id) return;
    S.bots.set(id, d.status);
    fillForm(d.config);
    renderList();
    renderDetail();
    const box = $('console');
    box.replaceChildren();
    for (const line of l.lines) appendLine(line, false);
    box.scrollTop = box.scrollHeight;
  } catch (e) {
    toast(e.message, true);
  }
}

function renderDetail() {
  const b = S.bots.get(S.selected);
  $('empty').classList.toggle('hidden', !!b);
  $('detail').classList.toggle('hidden', !b);
  if (!b) return;
  $('dName').textContent = b.name;
  $('dAddr').textContent = `${b.host}:${b.port}`;
  const badge = $('dBadge');
  badge.textContent = STATE_LABEL[b.state] || b.state;
  badge.className = 'badge s-' + b.state;
  $('stRecon').textContent = String(b.reconnects);
  $('stReason').textContent = b.lastReason || '-';
  $('btnStart').disabled = b.running;
  $('btnStop').disabled = !b.running;
  $('btnRestart').disabled = !b.running;
  tick();
}

function tick() {
  const b = S.bots.get(S.selected);
  if (!b) return;
  const now = Date.now();
  $('stUptime').textContent = b.state === 'online' && b.connectedAt ? fmtDur(now - b.connectedAt) : '-';
  $('stNextLabel').textContent = b.nextLabel ? `${b.nextLabel} in` : 'Next event';
  $('stNext').textContent = b.nextAt ? fmtDur(b.nextAt - now) : '-';
}
setInterval(tick, 1000);

async function action(name) {
  const id = S.selected;
  if (!id) return;
  try {
    const st = await api(`/bots/${id}/${name}`, { method: 'POST' });
    if (st && st.id) S.bots.set(st.id, st);
    renderList();
    renderDetail();
  } catch (e) {
    toast(e.message, true);
  }
}
$('btnStart').addEventListener('click', () => action('start'));
$('btnStop').addEventListener('click', () => action('stop'));
$('btnRestart').addEventListener('click', () => action('restart'));
$('btnDelete').addEventListener('click', async () => {
  const b = S.bots.get(S.selected);
  if (!b || !confirm(`"${b.name}" ko delete karna hai? Iski settings aur console history hamesha ke liye hat jayegi.`)) return;
  try {
    await api('/bots/' + b.id, { method: 'DELETE' });
    S.selected = null;
    history.replaceState(null, '', location.pathname);
    await loadList();
    toast('Bot delete ho gaya');
  } catch (e) {
    toast(e.message, true);
  }
});

/* ------------------------------------------------------------ tabs */
function showTab(name) {
  const isConsole = name === 'console';
  $('paneConsole').classList.toggle('hidden', !isConsole);
  $('settingsForm').classList.toggle('hidden', isConsole);
  $('tabBtnConsole').classList.toggle('active', isConsole);
  $('tabBtnSettings').classList.toggle('active', !isConsole);
  if (isConsole) $('console').scrollTop = $('console').scrollHeight;
}
document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => showTab(t.dataset.tab)));

/* ------------------------------------------------------------ console */
function appendLine(e, follow = true) {
  const box = $('console');
  const stick = box.scrollHeight - box.scrollTop - box.clientHeight < 48;
  box.append(el('div', { class: 'line ' + e.l }, el('time', { text: fmtTime(e.t) }), document.createTextNode(e.m)));
  while (box.childElementCount > MAX_CONSOLE_LINES) box.firstElementChild.remove();
  if (follow && stick) box.scrollTop = box.scrollHeight;
}

$('sayForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = $('sayInput').value.trim();
  if (!text || !S.selected) return;
  try {
    await api(`/bots/${S.selected}/say`, { method: 'POST', body: { text } });
    $('sayInput').value = '';
  } catch (err) {
    toast(err.message, true);
  }
});
$('clearBtn').addEventListener('click', async () => {
  if (!S.selected) return;
  try {
    await api(`/bots/${S.selected}/logs/clear`, { method: 'POST' });
  } catch (e) {
    toast(e.message, true);
  }
});

/* ------------------------------------------------------------ settings form */
const num = (id) => Number($(id).value);

function syncGroups() {
  document.querySelectorAll('.group[data-toggle]').forEach((g) => {
    const on = $(g.dataset.toggle).checked;
    g.classList.toggle('off', !on);
    g.querySelectorAll('.fields input, .fields textarea').forEach((i) => (i.disabled = !on));
  });
}
document.querySelectorAll('.group[data-toggle] .switch input').forEach((i) => i.addEventListener('change', syncGroups));

function fillForm(c) {
  $('s_name').value = c.name;
  $('s_host').value = c.host;
  $('s_port').value = c.port;
  $('s_version').value = c.version;
  $('s_chat_on').checked = c.chat.enabled;
  $('s_chat_msgs').value = c.chat.messages.join('\n');
  $('s_chat_int').value = c.chat.intervalSec;
  $('s_chat_rand').checked = c.chat.random;
  $('s_lr_on').checked = c.leaveRejoin.enabled;
  $('s_stay_min').value = c.leaveRejoin.stayMinSec;
  $('s_stay_max').value = c.leaveRejoin.stayMaxSec;
  $('s_away_min').value = c.leaveRejoin.awayMinSec;
  $('s_away_max').value = c.leaveRejoin.awayMaxSec;
  $('s_rc_on').checked = c.reconnect.enabled;
  $('s_rc_delay').value = c.reconnect.delaySec;
  $('s_rc_max').value = c.reconnect.maxDelaySec;
  $('s_auth_on').checked = c.auth.enabled;
  $('s_auth_pw').value = c.auth.password;
  $('s_afk').checked = c.antiAfk;
  $('s_chatlog').checked = c.chatLog;
  syncGroups();
}

function readForm() {
  return {
    name: $('s_name').value,
    host: $('s_host').value,
    port: num('s_port'),
    version: $('s_version').value,
    chat: { enabled: $('s_chat_on').checked, messages: $('s_chat_msgs').value, intervalSec: num('s_chat_int'), random: $('s_chat_rand').checked },
    leaveRejoin: {
      enabled: $('s_lr_on').checked,
      stayMinSec: num('s_stay_min'),
      stayMaxSec: num('s_stay_max'),
      awayMinSec: num('s_away_min'),
      awayMaxSec: num('s_away_max'),
    },
    reconnect: { enabled: $('s_rc_on').checked, delaySec: num('s_rc_delay'), maxDelaySec: num('s_rc_max') },
    auth: { enabled: $('s_auth_on').checked, password: $('s_auth_pw').value },
    antiAfk: $('s_afk').checked,
    chatLog: $('s_chatlog').checked,
  };
}

$('settingsForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!S.selected) return;
  try {
    const d = await api('/bots/' + S.selected, { method: 'PUT', body: readForm() });
    S.bots.set(S.selected, d.status);
    fillForm(d.config);
    renderList();
    renderDetail();
    toast('Settings save ho gayi');
  } catch (err) {
    toast(err.message, true);
  }
});

/* ------------------------------------------------------------ new bot */
$('newBtn').addEventListener('click', () => {
  $('newErr').textContent = '';
  $('newForm').reset();
  $('n_port').value = 25565;
  $('newDlg').showModal();
  $('n_name').focus();
});
$('newCancel').addEventListener('click', () => $('newDlg').close());
$('newForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('newErr').textContent = '';
  try {
    const r = await api('/bots', { method: 'POST', body: { name: $('n_name').value, host: $('n_host').value, port: num('n_port') } });
    $('newDlg').close();
    await loadList();
    await select(r.id);
    showTab('settings');
    toast('Bot ban gaya. Settings check karke Start dabao.');
  } catch (err) {
    $('newErr').textContent = err.message;
  }
});

/* ------------------------------------------------------------ live updates (SSE) */
function connectEvents() {
  if (S.es) S.es.close();
  const es = new EventSource('/api/events');
  S.es = es;
  es.addEventListener('status', (ev) => {
    const st = JSON.parse(ev.data);
    if (!S.bots.has(st.id)) return; // naya bot 'list' event se aayega
    S.bots.set(st.id, st);
    renderList();
    if (st.id === S.selected) renderDetail();
  });
  es.addEventListener('log', (ev) => {
    const e = JSON.parse(ev.data);
    if (e.id === S.selected) appendLine(e);
  });
  es.addEventListener('logclear', (ev) => {
    if (JSON.parse(ev.data).id === S.selected) $('console').replaceChildren();
  });
  es.addEventListener('list', () => loadList().catch(() => {}));
  es.addEventListener('open', () => loadList().catch(() => {}));
  es.onerror = () => {
    // 401 par browser reconnect band kar deta hai -> login check
    setTimeout(() => {
      if (es.readyState === EventSource.CLOSED && S.es === es) boot();
    }, 2000);
  };
}

/* ------------------------------------------------------------ boot */
async function boot() {
  try {
    await loadList();
  } catch {
    return; // 401 -> showLogin() already called
  }
  $('login').classList.add('hidden');
  $('app').classList.remove('hidden');
  connectEvents();
  const want = location.hash.slice(1);
  if (want && S.bots.has(want)) select(want);
  else if (!S.selected && S.bots.size) select(S.bots.keys().next().value);
}
boot();
