'use strict';
/**
 * Panel login. Password = env PANEL_PASSWORD.
 * Env nahi diya to ek random password ban kar DATA_DIR/panel-password.txt me
 * save hota hai aur Railway logs me print hota hai.
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const store = require('./store');

function loadPassword() {
  if (process.env.PANEL_PASSWORD) return { pw: process.env.PANEL_PASSWORD, generated: false };
  const file = path.join(store.DATA_DIR, 'panel-password.txt');
  try {
    const p = fs.readFileSync(file, 'utf8').trim();
    if (p) return { pw: p, generated: true };
  } catch {
    /* not created yet */
  }
  const pw = crypto.randomBytes(9).toString('base64url');
  try {
    fs.writeFileSync(file, pw + '\n', { mode: 0o600 });
  } catch {
    /* ignore */
  }
  return { pw, generated: true };
}

const { pw: PASSWORD, generated: GENERATED } = loadPassword();
const KEY = crypto.createHash('sha256').update('mcpanel-session:' + PASSWORD).digest();
const COOKIE = 'mcp_session';
const TTL = 7 * 24 * 3600 * 1000;

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
const sign = (exp) => crypto.createHmac('sha256', KEY).update(String(exp)).digest('base64url');

function checkPassword(input) {
  return crypto.timingSafeEqual(sha(input), sha(PASSWORD));
}
function makeToken() {
  const exp = Date.now() + TTL;
  return `${exp}.${sign(exp)}`;
}
function validToken(t) {
  if (typeof t !== 'string') return false;
  const [exp, sig] = t.split('.');
  if (!exp || !sig || !(Number(exp) > Date.now())) return false;
  const good = sign(exp);
  return sig.length === good.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good));
}
function cookiesOf(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

/* ---- brute force rokne ke liye: 8 galat try / 10 min / IP ---- */
const tries = new Map();
setInterval(() => {
  const now = Date.now();
  for (const [ip, t] of tries) if (t.reset < now) tries.delete(ip);
}, 60000).unref();

function isAuthed(req) {
  return validToken(cookiesOf(req)[COOKIE]);
}

module.exports = {
  GENERATED,
  PASSWORD,
  isAuthed,
  requireAuth(req, res, next) {
    if (isAuthed(req)) return next();
    res.status(401).json({ error: 'Login required' });
  },
  login(req, res) {
    const ip = req.ip || 'unknown';
    const now = Date.now();
    let t = tries.get(ip);
    if (!t || t.reset < now) t = { count: 0, reset: now + 10 * 60 * 1000 };
    if (t.count >= 8) return res.status(429).json({ error: 'Bahut zyada galat try. 10 minute baad try karo.' });
    const pw = req.body && typeof req.body.password === 'string' ? req.body.password : '';
    if (!checkPassword(pw)) {
      t.count++;
      tries.set(ip, t);
      return res.status(401).json({ error: 'Password galat hai.' });
    }
    tries.delete(ip);
    res.cookie(COOKIE, makeToken(), { httpOnly: true, sameSite: 'strict', secure: req.secure, maxAge: TTL, path: '/' });
    res.json({ ok: true });
  },
  logout(req, res) {
    res.clearCookie(COOKIE, { path: '/' });
    res.json({ ok: true });
  },
};
