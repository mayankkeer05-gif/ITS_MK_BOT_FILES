'use strict';
/**
 * BotManager = max 10 bots ko sambhalta hai. Har bot ek alag BotWorker
 * (alag config file, alag console log, alag timers).
 */
const EventEmitter = require('events');
const store = require('./store');
const { BotLogger } = require('./logger');
const { BotWorker } = require('./botWorker');

const MAX_BOTS = Math.max(1, parseInt(process.env.MAX_BOTS, 10) || 10);

class BotManager extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(100);
    this.workers = new Map();
    this.MAX_BOTS = MAX_BOTS;
  }

  _add(id, cfg) {
    const logger = new BotLogger(store.logPath(id));
    const w = new BotWorker(id, cfg, logger);
    w.on('status', (s) => this.emit('status', s));
    w.on('log', (e) => this.emit('log', e));
    w.on('logclear', (e) => this.emit('logclear', e));
    this.workers.set(id, w);
    return w;
  }

  /** Server start hote hi saved bots load; jo running the unhe 3s gap se start. */
  init() {
    let delay = 0;
    for (const id of store.listIds()) {
      const cfg = store.load(id);
      if (!cfg) {
        console.error(`[manager] ${id}: config unreadable, skipped`);
        continue;
      }
      const w = this._add(id, cfg);
      if (cfg.autoStart) {
        setTimeout(() => {
          if (this.workers.get(id) === w) w.start();
        }, delay);
        delay += 3000;
      }
    }
    console.log(`[manager] ${this.workers.size} bot(s) loaded`);
  }

  _get(id) {
    const w = this.workers.get(id);
    if (!w) store.fail('Bot not found', 404);
    return w;
  }

  _assertUnique(cfg, exceptId) {
    for (const [id, w] of this.workers) {
      if (id === exceptId) continue;
      const c = w.config;
      if (c.name.toLowerCase() === cfg.name.toLowerCase() && c.host.toLowerCase() === cfg.host.toLowerCase() && c.port === cfg.port) {
        store.fail('Is server par isi naam ka bot pehle se hai (dono ek dusre ko kick karenge).');
      }
    }
  }

  list() {
    return [...this.workers.values()]
      .sort((a, b) => a.config.createdAt - b.config.createdAt || a.id.localeCompare(b.id))
      .map((w) => w.getStatus());
  }

  details(id) {
    const w = this._get(id);
    return { status: w.getStatus(), config: w.config };
  }

  create(raw) {
    if (this.workers.size >= MAX_BOTS) store.fail(`Maximum ${MAX_BOTS} bots hi ban sakte hain. Pehle koi delete karo.`);
    if (!raw || !raw.name || !raw.host) store.fail('Bot name aur server IP zaroori hai.');
    const cfg = store.sanitize(raw);
    cfg.createdAt = Date.now();
    this._assertUnique(cfg, null);
    const id = store.newId();
    store.save(id, cfg);
    this._add(id, cfg);
    this.emit('list');
    return { id, status: this.workers.get(id).getStatus() };
  }

  update(id, raw) {
    const w = this._get(id);
    const cfg = store.sanitize(raw, w.config);
    this._assertUnique(cfg, id);
    store.save(id, cfg);
    w.applyConfig(cfg);
    return { status: w.getStatus(), config: cfg };
  }

  remove(id) {
    const w = this._get(id);
    w.shutdown();
    this.workers.delete(id);
    store.remove(id);
    this.emit('list');
  }

  _setAuto(w, id, on) {
    w.config.autoStart = on;
    store.save(id, w.config);
  }

  start(id) {
    const w = this._get(id);
    this._setAuto(w, id, true);
    w.start();
    return w.getStatus();
  }

  stop(id) {
    const w = this._get(id);
    this._setAuto(w, id, false);
    w.stop('Stopped from panel');
    return w.getStatus();
  }

  restart(id) {
    const w = this._get(id);
    this._setAuto(w, id, true);
    w.restart();
    return w.getStatus();
  }

  say(id, text) {
    this._get(id).say(text);
  }

  logs(id) {
    return this._get(id).log.getLines();
  }

  clearLogs(id) {
    this._get(id).log.clear();
  }

  /** Redeploy / SIGTERM par: bots band karo (autoStart flag same rehta hai). */
  shutdownAll() {
    for (const w of this.workers.values()) w.shutdown();
  }
}

module.exports = new BotManager();
