'use strict';
/**
 * BotWorker = ek bot. Sirf apni config, apna logger, apne timers.
 * States: stopped | connecting | online | away | reconnecting
 */
const EventEmitter = require('events');
const mineflayer = require('mineflayer');

const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const noop = () => {};

function userError(msg) {
  const e = new Error(msg);
  e.status = 400;
  return e;
}

/* ---- kick reason ko readable text me badalna ---- */
function simplify(n) {
  if (n && typeof n === 'object' && 'type' in n && 'value' in n) {
    if (n.type === 'compound') {
      if (Array.isArray(n.value)) return n.value.map((v) => simplify({ type: 'compound', value: v }));
      return Object.fromEntries(Object.entries(n.value).map(([k, v]) => [k, simplify(v)]));
    }
    if (n.type === 'list') return simplify(n.value);
    return n.value;
  }
  return n;
}
function toText(v) {
  v = simplify(v);
  if (v == null) return '';
  if (typeof v === 'string') {
    const s = v.trim();
    if (s[0] === '{' || s[0] === '[') {
      try {
        return toText(JSON.parse(s));
      } catch {
        /* plain text */
      }
    }
    return v;
  }
  if (Array.isArray(v)) return v.map(toText).join('');
  if (typeof v === 'object') {
    let t = typeof v.text === 'string' ? v.text : typeof v.translate === 'string' ? v.translate : '';
    if (Array.isArray(v.with)) t += ' ' + v.with.map(toText).join(' ');
    if (v.extra) t += toText(v.extra);
    return t;
  }
  return String(v);
}
function reasonText(reason) {
  let t = '';
  try {
    t = toText(reason);
  } catch {
    /* ignore */
  }
  t = t.replace(/\u00a7./g, '').trim();
  if (!t) {
    try {
      t = typeof reason === 'string' ? reason : JSON.stringify(reason);
    } catch {
      t = 'unknown';
    }
  }
  return (t || 'unknown').slice(0, 300);
}

class BotWorker extends EventEmitter {
  constructor(id, config, logger) {
    super();
    this.id = id;
    this.config = config;
    this.log = logger;

    this.bot = null;
    this.state = 'stopped';
    this.desired = false; // user ne start dabaya hai?
    this.attempts = 0;
    this.reconnects = 0;
    this.connectedAt = 0;
    this.nextAt = 0;
    this.nextLabel = '';
    this.lastReason = '';
    this.session = null;
    this.sessionTimers = new Set();
    this.timers = {};
    this.connectWatch = null;

    logger.on('line', (e) => this.emit('log', { id, ...e }));
    logger.on('clear', () => this.emit('logclear', { id }));
  }

  /* ------------------------------------------------ status */
  getStatus() {
    const c = this.config;
    return {
      id: this.id,
      name: c.name,
      host: c.host,
      port: c.port,
      state: this.state,
      running: this.desired,
      connectedAt: this.connectedAt,
      nextAt: this.nextAt,
      nextLabel: this.nextLabel,
      reconnects: this.reconnects,
      lastReason: this.lastReason,
    };
  }
  _emitStatus() {
    this.emit('status', this.getStatus());
  }
  _setState(s) {
    this.state = s;
    if (s === 'stopped' || s === 'connecting' || s === 'online') {
      this.nextAt = 0;
      this.nextLabel = '';
    }
    this._emitStatus();
  }
  _setNext(label, ms) {
    this.nextLabel = label;
    this.nextAt = Date.now() + ms;
    this._emitStatus();
  }

  /* ------------------------------------------------ timers */
  _timer(name, fn, ms) {
    this._clearTimer(name);
    this.timers[name] = setTimeout(() => {
      delete this.timers[name];
      try {
        fn();
      } catch (e) {
        this.log.err(`Internal error: ${e.message}`);
      }
    }, ms);
  }
  _clearTimer(name) {
    if (this.timers[name]) {
      clearTimeout(this.timers[name]);
      delete this.timers[name];
    }
  }
  _clearAllTimers() {
    for (const k of Object.keys(this.timers)) this._clearTimer(k);
  }
  /** Session timer: bot disconnect hote hi sab apne aap cancel. */
  _sTimer(fn, ms) {
    const h = setTimeout(() => {
      this.sessionTimers.delete(h);
      try {
        fn();
      } catch (e) {
        this.log.err(`Internal error: ${e.message}`);
      }
    }, ms);
    this.sessionTimers.add(h);
    return h;
  }
  _endSession() {
    for (const h of this.sessionTimers) clearTimeout(h);
    this.sessionTimers.clear();
    this.connectWatch = null;
    this.session = null;
  }

  /* ------------------------------------------------ public controls */
  start() {
    this._clearTimer('start');
    if (this.desired && this.state !== 'stopped') return;
    this.desired = true;
    this.attempts = 0;
    this._connect();
  }

  stop(why = 'Stopped') {
    const was = this.state !== 'stopped';
    this.desired = false;
    this._clearAllTimers();
    this._endSession();
    this._destroyBot();
    this.connectedAt = 0;
    this.attempts = 0;
    this._setState('stopped');
    if (was) this.log.sys(why);
  }

  restart() {
    this.stop('Restarting...');
    this._timer('start', () => this.start(), 1500);
  }

  shutdown() {
    this.desired = false;
    this._clearAllTimers();
    this._endSession();
    this._destroyBot();
    this.log.close();
  }

  say(text) {
    const t = String(text || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 256);
    if (!t) throw userError('Message khali hai.');
    if (!this.bot || this.state !== 'online') throw userError('Bot abhi online nahi hai.');
    this.bot.chat(t);
    this.log.cmd(`> ${t}`);
  }

  applyConfig(cfg) {
    const strip = (c) => JSON.stringify({ ...c, autoStart: 0, createdAt: 0 });
    const changed = strip(this.config) !== strip(cfg);
    this.config = cfg;
    if (changed && this.desired) {
      this.log.sys('Settings save hui - bot restart ho raha hai.');
      this.restart();
    } else {
      this._emitStatus();
    }
  }

  /* ------------------------------------------------ connection */
  _destroyBot() {
    const b = this.bot;
    this.bot = null;
    if (!b) return;
    try {
      b.quit();
    } catch {
      /* already closed */
    }
    const t = setTimeout(() => {
      try {
        b.end();
      } catch {
        /* ignore */
      }
    }, 1500);
    t.unref();
  }

  _connect() {
    if (!this.desired || this.bot) return;
    const c = this.config;
    this._setState('connecting');
    this.log.info(`Connecting to ${c.host}:${c.port} as ${c.name} ...`);

    const opts = {
      host: c.host,
      port: c.port,
      username: c.name,
      auth: 'offline',
      hideErrors: true,
      checkTimeoutInterval: 60000,
      viewDistance: 'tiny', // kam RAM / CPU
    };
    if (c.version) opts.version = c.version;

    let bot;
    try {
      bot = mineflayer.createBot(opts);
    } catch (e) {
      this.log.err(`Could not create bot: ${e.message}`);
      this.lastReason = e.message;
      this._scheduleReconnect();
      return;
    }
    this.bot = bot;
    this.session = { start: Date.now(), loginSent: false, registerSent: false, chatIdx: 0 };

    // 45s me spawn nahi hua to connection fail maan lo
    this.connectWatch = this._sTimer(() => {
      this.log.warn('Connection timeout (45s)');
      this._fail(bot, 'timeout');
    }, 45000);

    bot.once('login', () => {
      if (this.bot === bot) this.log.info('Logged in, waiting for spawn...');
    });
    bot.once('spawn', () => this._onSpawn(bot));
    bot.on('messagestr', (msg, position) => this._onChat(bot, msg, position));
    bot.on('kicked', (reason) => {
      if (this.bot !== bot) return;
      this.lastReason = reasonText(reason);
      this.log.warn(`Kicked: ${this.lastReason}`);
    });
    bot.on('error', (err) => this._onError(bot, err));
    bot.on('end', (reason) => this._onEnd(bot, reason));
  }

  _fail(bot, reason) {
    if (this.bot !== bot) return;
    try {
      bot.end();
    } catch {
      /* ignore */
    }
    this._onEnd(bot, reason);
  }

  _onError(bot, err) {
    if (this.bot !== bot) return;
    const msg = (err && (err.code ? `${err.code} ${err.message || ''}` : err.message)) || String(err);
    this.lastReason = msg.trim().slice(0, 200);
    this.log.err(`Error: ${this.lastReason}`);
    if (this.state === 'connecting') this._sTimer(() => this._fail(bot, msg), 3000);
  }

  _onEnd(bot, reason) {
    if (this.bot !== bot) return; // purana ya intentional (leave / stop)
    this.bot = null;
    this._endSession();
    this.connectedAt = 0;
    this.log.warn(`Disconnected${reason ? ` (${reasonText(reason)})` : ''}`);
    if (!this.desired) return this._setState('stopped');
    this._scheduleReconnect();
  }

  _scheduleReconnect() {
    const rc = this.config.reconnect;
    if (!rc.enabled) {
      this.desired = false;
      this.log.warn('Auto reconnect OFF hai - bot stop ho gaya.');
      return this._setState('stopped');
    }
    this.attempts++;
    this.reconnects++;
    let delay = Math.min(rc.maxDelaySec, rc.delaySec * 2 ** Math.min(this.attempts - 1, 6));
    if (/throttl|too fast|wait before|too quickly/i.test(this.lastReason)) delay = Math.max(delay, 30);
    delay = Math.max(1, Math.round(delay * (0.85 + Math.random() * 0.3)));
    this.log.info(`Reconnecting in ${delay}s (attempt ${this.attempts})`);
    this._setState('reconnecting');
    this._setNext('Reconnect', delay * 1000);
    this._timer('reconnect', () => this._connect(), delay * 1000);
  }

  /* ------------------------------------------------ in-game behaviour */
  _onSpawn(bot) {
    if (this.bot !== bot) return;
    if (this.connectWatch) {
      clearTimeout(this.connectWatch);
      this.sessionTimers.delete(this.connectWatch);
      this.connectWatch = null;
    }
    this.connectedAt = Date.now();
    this._setState('online');
    this.log.ok(`Joined ${this.config.host}:${this.config.port} as ${bot.username}`);
    // 60s stable raha to backoff reset
    this._sTimer(() => {
      this.attempts = 0;
    }, 60000);
    this._startChat(bot);
    this._startAfk(bot);
    this._startLeaveTimer(bot);
  }

  _onChat(bot, msg, position) {
    if (this.bot !== bot || position === 'game_info') return;
    const text = String(msg || '').trim();
    if (!text) return;
    if (this.config.chatLog) this.log.chat(text);
    this._handleAuth(bot, text);
  }

  _handleAuth(bot, text) {
    const a = this.config.auth;
    const s = this.session;
    if (!a.enabled || !a.password || !s) return;
    if (Date.now() - s.start > 90000) return; // sirf join ke baad pehle 90s
    const m = text.toLowerCase();
    let cmd = null;
    if (!s.loginSent && m.includes('/login')) {
      s.loginSent = true;
      cmd = `/login ${a.password}`;
    } else if (!s.registerSent && m.includes('/register')) {
      s.registerSent = true;
      cmd = `/register ${a.password} ${a.password}`;
    }
    if (!cmd) return;
    this._sTimer(() => {
      if (this.bot !== bot) return;
      try {
        bot.chat(cmd);
        this.log.sys(`Auth: ${cmd.split(' ')[0]} bhej diya`);
      } catch {
        /* ignore */
      }
    }, rnd(800, 1800));
  }

  _startChat(bot) {
    const c = this.config.chat;
    if (!c.enabled || !c.messages.length) return;
    const ms = c.intervalSec * 1000;
    const tick = () => {
      if (this.bot !== bot || this.state !== 'online') return;
      const msgs = c.messages;
      const text = c.random ? msgs[rnd(0, msgs.length - 1)] : msgs[this.session.chatIdx++ % msgs.length];
      try {
        bot.chat(text);
        this.log.cmd(`> ${text}`);
      } catch (e) {
        this.log.err(`Chat send failed: ${e.message}`);
      }
      this._sTimer(tick, ms);
    };
    this._sTimer(tick, Math.min(ms, 15000)); // pehla message jaldi, phir har interval
  }

  _startAfk(bot) {
    if (!this.config.antiAfk) return;
    const step = () => {
      if (this.bot !== bot) return;
      try {
        if (bot.entity) {
          bot.look(Math.random() * Math.PI * 2 - Math.PI, (Math.random() - 0.5) * 0.6, true);
          if (Math.random() < 0.6) {
            bot.setControlState('jump', true);
            this._sTimer(() => bot.setControlState('jump', false), 300);
          }
          if (Math.random() < 0.3) {
            bot.setControlState('sneak', true);
            this._sTimer(() => bot.setControlState('sneak', false), 700);
          } else {
            bot.swingArm();
          }
        }
      } catch {
        /* ignore */
      }
      this._sTimer(step, rnd(15000, 45000));
    };
    this._sTimer(step, rnd(5000, 15000));
  }

  _startLeaveTimer(bot) {
    const lr = this.config.leaveRejoin;
    if (!lr.enabled) return;
    const ms = rnd(lr.stayMinSec, lr.stayMaxSec) * 1000;
    this.log.info(`Server me ${Math.round(ms / 1000)}s rahega, phir leave karega`);
    this._setNext('Leave', ms);
    this._sTimer(() => this._leave(bot), ms);
  }

  _leave(bot) {
    if (this.bot !== bot) return;
    const lr = this.config.leaveRejoin;
    const away = rnd(lr.awayMinSec, lr.awayMaxSec) * 1000;
    this.log.info(`Leaving server (scheduled). ${Math.round(away / 1000)}s baad rejoin.`);
    this._endSession();
    this._destroyBot();
    this.connectedAt = 0;
    this._setState('away');
    this._setNext('Rejoin', away);
    this._timer(
      'rejoin',
      () => {
        this.attempts = 0;
        this._connect();
      },
      away
    );
  }
}

module.exports = { BotWorker, noop };
