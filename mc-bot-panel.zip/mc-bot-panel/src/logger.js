'use strict';
/**
 * Har bot ka apna console logger.
 * - RAM me last 500 lines (panel turant dikhata hai)
 * - Disk par console.log (JSON lines), 1 MB se bada ho to purani lines trim
 * - Writes batch me hoti hain (1.5s), isliye CPU/disk par load kam
 */
const fs = require('fs');
const EventEmitter = require('events');

const LEVELS = new Set(['info', 'ok', 'warn', 'err', 'chat', 'cmd', 'sys']);

class BotLogger extends EventEmitter {
  constructor(file, opts = {}) {
    super();
    this.file = file;
    this.memoryLines = opts.memoryLines || 500;
    this.maxBytes = opts.maxBytes || 1024 * 1024;
    this.keepLines = opts.keepLines || 400;
    this.lines = [];
    this.buf = [];
    this.flushes = 0;
    this.closed = false;
    this._load();
    this.timer = setInterval(() => this._flush(), 1500);
    this.timer.unref();
  }

  _readAll() {
    try {
      return fs.readFileSync(this.file, 'utf8').split('\n').filter(Boolean);
    } catch {
      return [];
    }
  }

  _load() {
    for (const l of this._readAll().slice(-this.memoryLines)) {
      try {
        const e = JSON.parse(l);
        if (e && typeof e.m === 'string') this.lines.push(e);
      } catch {
        /* corrupt line - skip */
      }
    }
    this._rotate();
  }

  _rotate() {
    try {
      if (fs.statSync(this.file).size <= this.maxBytes) return;
      fs.writeFileSync(this.file, this._readAll().slice(-this.keepLines).join('\n') + '\n');
    } catch {
      /* file not there yet */
    }
  }

  _flush() {
    if (!this.buf.length) return;
    const data = this.buf.join('');
    this.buf = [];
    try {
      fs.appendFileSync(this.file, data);
      if (++this.flushes % 40 === 0) this._rotate();
    } catch {
      /* disk error - ignore, RAM log still works */
    }
  }

  log(level, msg) {
    if (this.closed) return;
    const e = {
      t: Date.now(),
      l: LEVELS.has(level) ? level : 'info',
      m: String(msg)
        .replace(/\u00a7[0-9a-fk-or]/gi, '')
        .replace(/[\u0000-\u0008\u000b-\u001f]/g, ' ')
        .slice(0, 600),
    };
    this.lines.push(e);
    if (this.lines.length > this.memoryLines) this.lines.shift();
    this.buf.push(JSON.stringify(e) + '\n');
    this.emit('line', e);
  }

  info(m) { this.log('info', m); }
  ok(m) { this.log('ok', m); }
  warn(m) { this.log('warn', m); }
  err(m) { this.log('err', m); }
  chat(m) { this.log('chat', m); }
  cmd(m) { this.log('cmd', m); }
  sys(m) { this.log('sys', m); }

  getLines() {
    return this.lines;
  }

  clear() {
    this.lines = [];
    this.buf = [];
    try {
      fs.writeFileSync(this.file, '');
    } catch {
      /* ignore */
    }
    this.emit('clear');
  }

  close() {
    if (this.closed) return;
    this._flush();
    this.closed = true;
    clearInterval(this.timer);
  }
}

module.exports = { BotLogger };
