'use strict';
/**
 * Per-bot file storage.
 *   <DATA_DIR>/bots/<id>/config.json   -> sirf is bot ki settings
 *   <DATA_DIR>/bots/<id>/console.log   -> sirf is bot ki console history
 * Har bot ki files alag hain, kuch mix nahi hota.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.resolve(
  process.env.DATA_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH || path.join(__dirname, '..', 'data')
);
const BOTS_DIR = path.join(DATA_DIR, 'bots');
const ID_RE = /^b_[a-f0-9]{8}$/;
fs.mkdirSync(BOTS_DIR, { recursive: true });

function defaults() {
  return {
    name: 'MyBot001',
    host: 'localhost',
    port: 25565,
    version: '', // '' = auto detect
    chat: { enabled: true, messages: ['Hello!'], intervalSec: 120, random: false },
    reconnect: { enabled: true, delaySec: 5, maxDelaySec: 60 },
    leaveRejoin: { enabled: true, stayMinSec: 600, stayMaxSec: 900, awayMinSec: 30, awayMaxSec: 60 },
    auth: { enabled: false, password: '' },
    antiAfk: true,
    chatLog: true,
    autoStart: false,
    createdAt: 0,
  };
}

function fail(msg, status = 400) {
  const e = new Error(msg);
  e.status = status;
  throw e;
}
const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);
function int(v, min, max, fb) {
  if (v === undefined || v === null || v === '') return fb;
  const n = Math.round(Number(v));
  if (!Number.isFinite(n)) return fb;
  return Math.min(max, Math.max(min, n));
}
const bool = (v, fb) => (typeof v === 'boolean' ? v : fb);

/** Koi bhi input -> safe, complete config. Missing keys `cur` se aate hain. */
function sanitize(raw, cur = defaults()) {
  const r = isObj(raw) ? raw : {};
  const sub = (k) => (isObj(r[k]) ? r[k] : {});
  const chat = sub('chat');
  const rc = sub('reconnect');
  const lr = sub('leaveRejoin');
  const au = sub('auth');

  let name = cur.name;
  if (r.name !== undefined) {
    name = String(r.name).trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) fail('Bot name 3-16 characters ka hona chahiye (sirf A-Z, 0-9, _).');
  }
  let host = cur.host;
  if (r.host !== undefined) {
    host = String(r.host).trim();
    if (!/^[A-Za-z0-9._-]{1,253}$/.test(host)) fail('Server IP / address galat hai.');
  }
  let version = cur.version;
  if (r.version !== undefined) {
    version = String(r.version).trim();
    if (version.toLowerCase() === 'auto') version = '';
    if (version && !/^1\.\d{1,2}(\.\d{1,2})?$/.test(version)) fail('Version aisa hona chahiye: 1.20.1 (ya khali chhodo = auto).');
  }

  let messages = cur.chat.messages;
  if (chat.messages !== undefined) {
    const arr = Array.isArray(chat.messages) ? chat.messages : String(chat.messages).split(/\r?\n/);
    messages = arr
      .map((m) => String(m).replace(/[\u0000-\u001f\u007f\u00a7]/g, '').trim().slice(0, 256))
      .filter(Boolean)
      .slice(0, 30);
  }

  const stayMin = int(lr.stayMinSec, 5, 86400, cur.leaveRejoin.stayMinSec);
  const awayMin = int(lr.awayMinSec, 1, 86400, cur.leaveRejoin.awayMinSec);
  const delay = int(rc.delaySec, 1, 3600, cur.reconnect.delaySec);

  return {
    name,
    host,
    port: int(r.port, 1, 65535, cur.port),
    version,
    chat: {
      enabled: bool(chat.enabled, cur.chat.enabled),
      messages,
      intervalSec: int(chat.intervalSec, 3, 86400, cur.chat.intervalSec),
      random: bool(chat.random, cur.chat.random),
    },
    reconnect: {
      enabled: bool(rc.enabled, cur.reconnect.enabled),
      delaySec: delay,
      maxDelaySec: Math.max(delay, int(rc.maxDelaySec, 1, 3600, cur.reconnect.maxDelaySec)),
    },
    leaveRejoin: {
      enabled: bool(lr.enabled, cur.leaveRejoin.enabled),
      stayMinSec: stayMin,
      stayMaxSec: Math.max(stayMin, int(lr.stayMaxSec, 5, 86400, cur.leaveRejoin.stayMaxSec)),
      awayMinSec: awayMin,
      awayMaxSec: Math.max(awayMin, int(lr.awayMaxSec, 1, 86400, cur.leaveRejoin.awayMaxSec)),
    },
    auth: {
      enabled: bool(au.enabled, cur.auth.enabled),
      password: au.password !== undefined ? String(au.password).replace(/\s/g, '').slice(0, 64) : cur.auth.password,
    },
    antiAfk: bool(r.antiAfk, cur.antiAfk),
    chatLog: bool(r.chatLog, cur.chatLog),
    autoStart: cur.autoStart === true,
    createdAt: Number(cur.createdAt) || 0,
  };
}

function assertId(id) {
  if (!ID_RE.test(String(id))) fail('Bot not found', 404);
}
const dirOf = (id) => {
  assertId(id);
  return path.join(BOTS_DIR, id);
};

module.exports = {
  DATA_DIR,
  defaults,
  sanitize,
  fail,
  newId: () => 'b_' + crypto.randomBytes(4).toString('hex'),
  logPath: (id) => path.join(dirOf(id), 'console.log'),
  listIds() {
    try {
      return fs
        .readdirSync(BOTS_DIR, { withFileTypes: true })
        .filter((d) => d.isDirectory() && ID_RE.test(d.name))
        .map((d) => d.name);
    } catch {
      return [];
    }
  },
  load(id) {
    try {
      const raw = JSON.parse(fs.readFileSync(path.join(dirOf(id), 'config.json'), 'utf8'));
      const cfg = sanitize(raw);
      cfg.autoStart = raw.autoStart === true;
      cfg.createdAt = Number(raw.createdAt) || 0;
      return cfg;
    } catch {
      return null;
    }
  },
  save(id, cfg) {
    const dir = dirOf(id);
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, 'config.json');
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2));
    fs.renameSync(tmp, file);
  },
  remove(id) {
    fs.rmSync(dirOf(id), { recursive: true, force: true });
  },
};
